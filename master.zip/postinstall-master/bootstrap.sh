#!/usr/bin/env bash

#
# Bootstrap file für die initiale Konfiguration des Post-Install-Skript.
#

